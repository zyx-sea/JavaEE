package cn.taotao.july.service;

import cn.taotao.july.pojo.Book;

import java.util.List;

/**
 * 哲学类书籍<br>
 * create:2017-05-09 15:03
 *
 * @author zhou
 */
public interface BookPhService {
    List<Book>  findBookPh();
}
