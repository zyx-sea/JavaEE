package cn.taotao.july.mapper;

import cn.taotao.july.pojo.Content;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author zhou
 * @since 2017-05-02
 */
public interface ContentMapper extends BaseMapper<Content> {

}