package cn.taotao.july.mapper;

import cn.taotao.july.pojo.Manager;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author zhou
 * @since 2017-05-15
 */
public interface ManagerMapper extends BaseMapper<Manager> {

}