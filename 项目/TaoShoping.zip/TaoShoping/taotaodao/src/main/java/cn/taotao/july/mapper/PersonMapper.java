package cn.taotao.july.mapper;

import cn.taotao.july.pojo.Person;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author zhou
 * @since 2017-05-02
 */
public interface PersonMapper extends BaseMapper<Person> {

}