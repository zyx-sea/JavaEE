package cn.taotao.july.controller;

import cn.taotao.july.pojo.Users;
import cn.taotao.july.service.UserService;
import com.baomidou.mybatisplus.plugins.Page;
import com.opensymphony.xwork2.ActionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <br>
 * create:2017-04-27 16:49
 *
 * @author zhou
 */

@Controller
@Scope("prototype")
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping("/comlogin")
    public  String login(Users user){
        //调用findUserByName()方法来验证是否是注册用户
        Users u=userService.findUserByName(user.getUsersUsername());
        ActionContext ac = ActionContext.getContext();
        Map<String, Object> session = ac.getSession();
        if (u!=null&&u.getUsersPassword().equals(user.getUsersPassword())){
            /*如果验证成功，将用户信息传到前台*/
            session.put("user",user);
            System.out.println(user.getUsersUsername());
            /*并跳转到首页*/
            return "index";
        }else {
            /*若不对，留在登录页面不跳转*/
            return "login";
        }
    }
    @RequestMapping("/register")
    public  String register(Users users){
        int userTotal=0;
        if (users.getUsersName()==null){
            userTotal=userService.insertUser(users);
        }else{
            userTotal=userService.update(users);
        }
        if (userTotal>0){
            return "index";
        }else {
            return  "login";
        }
    }
    @RequestMapping("/admin")
    public String adminlogin(){
        return "admin/index";
    }
    @RequestMapping("/userQuery")
    public String userQuery(){
        return "admin/userQuery";
    }

    @RequestMapping("/user/{username}")
    @ResponseBody
    public Users findUserByUsername(@PathVariable  String username){
        return userService.findUserByName(username);
    }
    @RequestMapping("/getall")
    @ResponseBody
    public List<Users> getAll(){
        return userService.getAllUsers();
    }
    @RequestMapping("/insert")
    @ResponseBody
    public Map<String,Boolean> insert(Users users){
        int userTotal=0;
        Map<String,Boolean> map=new HashMap<String, Boolean>() ;
        if (users.getUsersName()==null){
            userTotal=userService.insertUser(users);
        }else{
            userTotal=userService.update(users);
        }
        if (userTotal>0){
            map.put("success",true);
        }else {
            map.put("success",false);
        }
        return map;
    }
    @RequestMapping("/delete")
    @ResponseBody
    public Map<String,Boolean>  delete(@RequestParam(value = "id") String id){
        int userTotal=0;
        Map<String,Boolean> map=new HashMap<String, Boolean>();
        userService.delete(Integer.parseInt(id));
        map.put("success",true);
        return map;
    }
    public Page selectPage(@PathVariable Integer page, @PathVariable Integer rows){
        return userService.selectUser(page, rows);
    }

}
